package com.example.myfitnessapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.myfitnessapp.Api.NutritionixRequest;
import com.example.myfitnessapp.Api.NutritionixResponse;
import com.example.myfitnessapp.Api.apiset;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import com.example.myfitnessapp.Api.NutritionixResponse;

public class MainActivity extends AppCompatActivity {


    private static final String BASE_URL="https://trackapi.nutritionix.com/";
    private static final String TAG = MainActivity.class.getSimpleName();

    apiset api;

   // NutritionixRequest request;
    String query;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        query="apple";
        fetchData(query);



        // request = new NutritionixRequest(query);
    }

    public void fetchData(String query){

        Retrofit retrofit=new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api=retrofit.create(apiset.class);


        Call<NutritionixResponse> call=api.getNutrients(query);
        call.enqueue(new Callback<NutritionixResponse>() {
            @Override
            public void onResponse(Call<NutritionixResponse> call, Response<NutritionixResponse> response) {
                if (response.isSuccessful() && response.body() != null){
                    NutritionixResponse nutritionixResponse= response.body();

                    Log.d(TAG, "Food Name: " + nutritionixResponse.getFoods().get(0).getFoodName());
                    Log.d(TAG, "Calories: " + nutritionixResponse.getFoods().get(0).getCalories());

                    for (NutritionixResponse.Food.Nutrient nutrient : nutritionixResponse.getFoods().get(0).getFullNutrients()) {
                        Log.d(TAG, "Nutrient ID: " + nutrient.getAttrId() + ", Value: " + nutrient.getValue());
                    }
                } else {
                    Log.e(TAG, "Failed to fetch data: " + response.message());
                }
                }


            @Override
            public void onFailure(Call<NutritionixResponse> call, Throwable t) {
                Log.e(TAG, "Failed to communicate with server: " + t.getMessage());
            }
        });
    }
}